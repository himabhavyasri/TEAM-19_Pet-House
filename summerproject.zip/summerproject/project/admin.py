from django.contrib import admin

from project.models import UserProfileInfo

from project.models import Booking

admin.site.register(UserProfileInfo)
admin.site.register(Booking)
