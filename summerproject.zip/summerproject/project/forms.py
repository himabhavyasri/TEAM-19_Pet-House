from django import forms
from django.contrib.auth.models import User
from project.models import UserProfileInfo
from project.models import Booking

class UserForm(forms.ModelForm):
    class Meta():
        model = UserProfileInfo
        fields = ('username','password','email')
class BookingForm(forms.ModelForm):
    class Meta():
        model = Booking
        fields = ('username','email','mobilenumber','petname','date','slot','servicetype','transport')

