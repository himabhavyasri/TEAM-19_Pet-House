#/models.py
from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class UserProfileInfo(models.Model):
	username = models.CharField(max_length=30, default='')
	password = models.CharField(max_length=10,default='')
	email = models.CharField(max_length=30, default='@gmail.com')

def __str__(self):
  return self.UserProfileInfo.username, self.UserProfileInfo.password

SLOT_CHOICES = (
        ('Morning', 'MORNING'),
	('Afternoon', 'AFTERNOON'),
	('Evening', 'EVENING')
)

SERVICE_CHOICES = (
	('HomeService', 'HOMESERVICE'),
	('ShopService', 'SHOPSERVICE')
)

TRANSPORT_CHOICES = (
	('Yes','YES'),
	('No','NO')
)
class Booking(models.Model):
        username = models.CharField(max_length=30, default='')
        email = models.CharField(max_length=30, default='@gmail.com')
        mobilenumber = models.CharField(max_length=10)
        petname = models.CharField(max_length=10, default='')
        date = models.DateField(max_length = 30, default='')
        slot = models.CharField(max_length=10, choices=SLOT_CHOICES, default='MORNING')
        servicetype = models.CharField(max_length=20, choices=SERVICE_CHOICES, default='HOMESERVICE')
        transport = models.CharField(max_length=3,choices=TRANSPORT_CHOICES,default="YES")
	



