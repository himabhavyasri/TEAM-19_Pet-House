from django.shortcuts import render
from project.forms import UserForm, BookingForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from project.models import UserProfileInfo
from project.models import Booking

def index(request):
    return render(request,'index.html')

@login_required
def special(request):
    return HttpResponse("You are logged in !")

def user_logout(request):
    logout(request)
    return render(request,'index.html')

def welcome(request):
    return render(request,'welcome.html')

def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
       
        if user_form.is_valid():
            user = user_form.save()
            user.save()
            registered = True
            return render(request,'welcome.html',{'user_form':user_form,'registered':registered})
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
    return render(request,'register.html',{'user_form':user_form,'registered':registered})

def form(request):
    booked = False
    if request.method == 'POST':
        book_form = BookingForm(data=request.POST)
       
        if book_form.is_valid():
            user = book_form.save()
            user.save()
            booked = True
            #return render(request,'index.html',{'book_form':book_form,'booked':booked})
            return render(request,'message.html')
        else:
            print(book_form.errors)
    else:
        book_form = BookingForm()
    return render(request,'form.html',{'book_form':book_form,'booked':booked})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        a = UserProfileInfo.objects.filter(username=username).exists()
        b = UserProfileInfo.objects.filter(password=password).exists()
        if a and b:
            #login(request,user)
            return HttpResponseRedirect('form')
            #return render(request, 'form.html')
        #else:
  #          return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
            #return render(request, 'form.html')
    else:
        return render(request, 'user_login.html')

